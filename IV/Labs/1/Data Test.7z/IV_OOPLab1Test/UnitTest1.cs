﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OOP_Simple_class_C_Sharp__BAS;
using System.Collections.Generic;


namespace IV_OOPLab1Test
{
    [TestClass]
    public class TestData
    {
        private Data D = new Data();
        string[] MonthNames = 
        { 
            "январь", "февраль", "март", "апрель", 
            "май", "июнь", "июль", "август", "сентябрь", 
            "октябрь", "ноябрь", "декабрь" 
        };

        [TestMethod]
        public void TestIsLeapYear()
        {
            int[] leapYears = { 0, 4, 8, 400, 2020, 2104, 404 };
            int[] notLeapYears = { 1, 5, 9, 100, 2100, 2021, 401 };

            bool result;

            foreach (var Year in leapYears)
            {
                D.Year = Year;

                result = D.YearLeapness;

                Assert.IsTrue(result, $"Expected for {Year}: true; Actual: {result}");
            }

            foreach (var Year in notLeapYears)
            {
                D.Year = Year;

                result = D.YearLeapness;

                Assert.IsFalse(result, $"Expected for {Year}: true; Actual: {result}");
            }

        }

        [TestMethod]
        public void TestGetMonthName()
        {
            for (int i = 0; i < MonthNames.Length; i++)
            {
                D.Month = i + 1;

                string result = D.MonthName.ToLower();

                Assert.AreEqual(MonthNames[i], result, $"Expected: {MonthNames[i]}; Actual: {D.Month}");
            }
        }

        [TestMethod]
        public void TestGetMonthNumByMonthName()
        {
            for (int i = 0; i < MonthNames.Length; i++)
            {
                int result = D.GetMonthNumberByMonthName(MonthNames[i]);

                Assert.AreEqual(i + 1, result, $"Expected: {i + 1}; Actual: {result}");
            }
        }


        [TestMethod]
        public void TestDaysAmount()
        {
            int[] monthsWith30Days = { 4, 6, 9 };
            int[] monthsWith31Days = { 1, 3, 5, 7, 8, 10, 12 };

            int result;

            foreach (int month in monthsWith30Days)
            {
                D.Month = month;

                result = D.DaysAmount;

                Assert.AreEqual(30, result, $"Expected: 30; Actual: {result}");
            }

            foreach (int month in monthsWith31Days)
            {
                D.Month = month;

                result = D.DaysAmount;

                Assert.AreEqual(31, result, $"Expected: 31; Actual: {result}");
            }

            D.Month = 2;
            D.Year = 3;

            result = D.DaysAmount;

            Assert.AreEqual(28, result, $"Expected: 28; Actual: {result}");


            D.Year = 2020;

            result = D.DaysAmount;

            Assert.AreEqual(29, result, $"Expected: 29; Actual: {result}");
        }


    }
}
