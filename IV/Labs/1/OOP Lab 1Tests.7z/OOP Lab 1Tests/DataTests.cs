﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DataLib.Tests
{
    [TestClass()]
    public class DataTests
    {
        private Data D = new Data();
        string[] monthNames =
        {
            "Junuary", "February", "March", "April",
            "May", "June", "July", "August", "September",
            "October", "November", "December"
        };

        [TestMethod]
        public void TestIsLeapYear()
        {
            int[] leapYears = { 0, 4, 8, 400, 2020, 2104, 404 };
            int[] notLeapYears = { 1, 5, 9, 100, 2100, 2021, 401 };

            bool result;

            foreach (var Year in leapYears)
            {
                D.Year = Year;

                result = D.YearLeapness;

                Assert.IsTrue(result, $"Expected for {Year}: true; Actual: {result}");
            }

            foreach (var Year in notLeapYears)
            {
                D.Year = Year;

                result = D.YearLeapness;

                Assert.IsFalse(result, $"Expected for {Year}: true; Actual: {result}");
            }

        }

        [TestMethod]
        public void TestGetMonthName()
        {
            for (int i = 0; i < monthNames.Length; i++)
            {
                D.Month = i + 1;

                string result = D.MonthName;

                Assert.AreEqual(monthNames[i], result, $"Expected: {monthNames[i]}; Actual: {D.MonthName}");
            }
        }

        [TestMethod]
        public void TestGetMonthNumberByMonthName()
        {
            for (int i = 0; i < monthNames.Length; i++)
            {
                int result = Data.GetMonthNumberByMonthName(monthNames[i]);

                Assert.AreEqual(i + 1, result, $"Expected: {i + 1}; Actual: {result}");
            }
        }

        [TestMethod]
        public void TestDaysAmount()
        {
            int[] monthsWith30Days = { 4, 6, 9, 11 };
            int[] monthsWith31Days = { 1, 3, 5, 7, 8, 10, 12 };

            int result;

            foreach (int month in monthsWith30Days)
            {
                D.Month = month;

                result = D.DaysAmount;

                Assert.AreEqual(30, result, $"Expected: 30; Actual: {result}");
            }

            foreach (int month in monthsWith31Days)
            {
                D.Month = month;

                result = D.DaysAmount;

                Assert.AreEqual(31, result, $"Expected: 31; Actual: {result}");
            }

            D.Month = 2;
            D.Year = 3;

            result = D.DaysAmount;

            Assert.AreEqual(28, result, $"Expected: 28; Actual: {result}");


            D.Year = 2020;

            result = D.DaysAmount;

            Assert.AreEqual(29, result, $"Expected: 29; Actual: {result}");
        }

        [TestMethod]
        public void TestExceptionsThrows()
        {
            int[] invalidData = { 0, -1, -9, -28, 100, 38, 90, -12};

            Exception exc = null;

            foreach (int month in invalidData)
            {
                exc = null;
                exc = Assert.ThrowsException<Exception>(() => D.Month = month);
                Assert.IsNotNull(exc, $"Expected: null; Actual: {exc}");
            }

            foreach (int day in invalidData)
            {
                exc = null;
                exc = Assert.ThrowsException<Exception>(() => D.Day = day);
                Assert.IsNotNull(exc, $"Expected: null; Actual: {exc}");
            }

            foreach (int year in invalidData)
            {
                exc = null;
                exc = Assert.ThrowsException<Exception>(() => D.Year = Math.Abs(year) * -1 - 1);
                Assert.IsNotNull(exc, $"Expected: null; Actual: {exc}");
            }
        }

    }
}