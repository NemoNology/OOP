﻿using System;
using OOP_Simple_class_C_Sharp__BAS;
using System.Windows.Forms;

namespace OOP_Lab_1
{
    public partial class Form1 : Form
    {
        private Data data = new Data();

        public Form1()
        {
            InitializeComponent();
        }

        private void Data_Changed(object sender, EventArgs e)
        {
            int year = (int)input_year.Value;
            int month = (int)input_month.Value;
            int day = (int)input_day.Value;

            try 
            {
                data.Year = year;
                data.Month = month;
                data.Day = day;


                if (data.YearLeapness)
                {
                    leapness.Text = "Да";
                }
                else
                {
                    leapness.Text = "Нет";
                }

                daysAmount.Text = data.DaysAmount.ToString();
                monthName.Text = data.MonthName;

                status.Text = null;
            }
            catch (Exception exp)
            {
                status.Text = exp.Message;

                leapness.Text = daysAmount.Text = monthName.Text = null;
            }
        }
    }
}
