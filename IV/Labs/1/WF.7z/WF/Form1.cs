﻿using System;
using DataLib;
using System.Windows.Forms;
using System.Linq;

namespace WF
{
    public partial class Form1 : Form
    {
        private Data data = new Data();

        public Form1()
        {
            InitializeComponent();
        }

        private void Data_Changed(object sender, EventArgs e)
        {
            int year = (int)input_year.Value;
            int month = (int)input_month.Value;
            int day = (int)input_day.Value;

            try 
            {
                data.Year = year;
                data.Month = month;
                data.Day = day;


                if (data.YearLeapness)
                {
                    leapness.Text = "Да";
                }
                else
                {
                    leapness.Text = "Нет";
                }

                daysAmount.Text = data.DaysAmount.ToString();
                monthName.Text = data.MonthName;

                status.Text = null;
            }
            catch (Exception exp)
            {
                status.Text = exp.Message;

                leapness.Text = daysAmount.Text = monthName.Text = null;
            }
        }

        private void b_generate_Click(object sender, EventArgs e)
        {
            arrayOfData.Lines = null;

            int size = 10;

            Data[] datas = new Data[size];

            Random rnd = new Random();

            for (int i = 0; i < size; i++)
            {
                datas[i] = new Data(rnd.Next(0, 5000), rnd.Next(1, 12));
                datas[i].Day = rnd.Next(1, datas[i].DaysAmount);
            }

            foreach (Data data in datas)
            {
                arrayOfData.Lines = arrayOfData.Lines.Append(Data.GetData(data)).ToArray<string>();
            }
        }
    }
}
