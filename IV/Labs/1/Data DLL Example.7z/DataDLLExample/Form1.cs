﻿using System.Windows.Forms;
using DataLib;

namespace DataDLLExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Data dataExample = new Data();

            year.Text = dataExample.Year.ToString();
            month.Text = dataExample.MonthName;
            day.Text = dataExample.Day.ToString();
            yearLeapness.Text = dataExample.YearLeapness.ToString();
            daysAmount.Text = dataExample.DaysAmount.ToString();
            monthNumber.Text = dataExample.Month.ToString();
        }
    }
}
