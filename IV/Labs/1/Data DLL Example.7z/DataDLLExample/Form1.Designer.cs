﻿
namespace DataDLLExample
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.daysAmount = new System.Windows.Forms.Label();
            this.monthNumber = new System.Windows.Forms.Label();
            this.yearLeapness = new System.Windows.Forms.Label();
            this.day = new System.Windows.Forms.Label();
            this.month = new System.Windows.Forms.Label();
            this.year = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Год: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Месяц: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "День: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Високосность года: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Количество дней в месяце:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Номер месяца:";
            // 
            // daysAmount
            // 
            this.daysAmount.AutoSize = true;
            this.daysAmount.Location = new System.Drawing.Point(164, 124);
            this.daysAmount.Name = "daysAmount";
            this.daysAmount.Size = new System.Drawing.Size(16, 13);
            this.daysAmount.TabIndex = 0;
            this.daysAmount.Text = "...";
            // 
            // monthNumber
            // 
            this.monthNumber.AutoSize = true;
            this.monthNumber.Location = new System.Drawing.Point(164, 163);
            this.monthNumber.Name = "monthNumber";
            this.monthNumber.Size = new System.Drawing.Size(16, 13);
            this.monthNumber.TabIndex = 0;
            this.monthNumber.Text = "...";
            // 
            // yearLeapness
            // 
            this.yearLeapness.AutoSize = true;
            this.yearLeapness.Location = new System.Drawing.Point(164, 92);
            this.yearLeapness.Name = "yearLeapness";
            this.yearLeapness.Size = new System.Drawing.Size(16, 13);
            this.yearLeapness.TabIndex = 0;
            this.yearLeapness.Text = "...";
            // 
            // day
            // 
            this.day.AutoSize = true;
            this.day.Location = new System.Drawing.Point(164, 61);
            this.day.Name = "day";
            this.day.Size = new System.Drawing.Size(16, 13);
            this.day.TabIndex = 0;
            this.day.Text = "...";
            // 
            // month
            // 
            this.month.AutoSize = true;
            this.month.Location = new System.Drawing.Point(164, 34);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(16, 13);
            this.month.TabIndex = 0;
            this.month.Text = "...";
            // 
            // year
            // 
            this.year.AutoSize = true;
            this.year.Location = new System.Drawing.Point(164, 9);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(16, 13);
            this.year.TabIndex = 0;
            this.year.Text = "...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 205);
            this.Controls.Add(this.year);
            this.Controls.Add(this.month);
            this.Controls.Add(this.day);
            this.Controls.Add(this.yearLeapness);
            this.Controls.Add(this.monthNumber);
            this.Controls.Add(this.daysAmount);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label daysAmount;
        private System.Windows.Forms.Label monthNumber;
        private System.Windows.Forms.Label yearLeapness;
        private System.Windows.Forms.Label day;
        private System.Windows.Forms.Label month;
        private System.Windows.Forms.Label year;
    }
}

